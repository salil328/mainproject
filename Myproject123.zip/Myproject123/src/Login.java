import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

@WebServlet("/Login")
public class Login extends HttpServlet {
	
	
//	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
//		try {
//			res.setContentType("text/html");
//			PrintWriter pw = res.getWriter();
//			String a = req.getParameter("t1");
//			String b = req.getParameter("t2");
//			Configuration cfg = new Configuration();
//			SessionFactory sf = cfg.configure().buildSessionFactory();
//			Session ss = sf.openSession();
//			mypojo pojo = new mypojo();
//			pojo.setUsername(a);
//			pojo.setPassword(b);
//			Transaction tx = ss.beginTransaction();
//			ss.save(pojo);
//			tx.commit();
//			ss.close();
//			System.out.println("hi");
//		//	res.sendRedirect("success.html");
//		} catch (Exception ae) {
//		}
//	}
//	
	
	PreparedStatement st = null;
	Connection con = null;
	ResultSet rs = null;
	int i = 0;

	public void init() {
		System.out.println("init");
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system", "123456789");
			System.out.println("connected");
		} catch (Exception ae) {
		}
	}

	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
//		 HttpSession session=req.getSession(true);  
		String a = req.getParameter("t1");
		String b = req.getParameter("t2");
		
		if(a.equals("admin")&& b.equals("admin")) {
			res.sendRedirect("NewFile.jsp");
		}

		System.out.println(a);
		System.out.println(b);
		try {

			st = con.prepareStatement("select * from registration where Username=? and Password=?");
			st.setString(1, a);
			st.setString(2, b);
			rs = st.executeQuery();
			while (rs.next()) {
				i = 1;
			}
			if (i == 1)
				res.sendRedirect("vehicleregister.jsp");

			else
				res.sendRedirect("failure.jsp");
			
			System.out.println("Working");
			
			

		} catch (Exception ae) {
			
			ae.printStackTrace();
		}

		out.println("</body>");
		out.println("</html>");
	}

}