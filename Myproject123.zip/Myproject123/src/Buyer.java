import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
@WebServlet("/Buyer")
public class Buyer extends HttpServlet {
	public void service(HttpServletRequest req,HttpServletResponse res)
			throws ServletException,IOException
	{		try
		{	res.setContentType("text/html");
			PrintWriter pw=res.getWriter();
			String a=req.getParameter("t1");
			String b=req.getParameter("t2");
			String c=req.getParameter("t3");
			String d=req.getParameter("t4");
			String e=req.getParameter("t5");
			String f=req.getParameter("t6");
			String g=req.getParameter("t7");
			String h=req.getParameter("t8");
			String i=req.getParameter("t9");
			String j=req.getParameter("t10");
			String k=req.getParameter("t11");
			Configuration cfg=new Configuration();
			SessionFactory sf=cfg.configure().buildSessionFactory();
			Session ss=sf.openSession();
			BuyerPojo bpj=new BuyerPojo();
			
			bpj.setName(a);
			bpj.setLstname(b);
			bpj.setAdd(c);
			bpj.setCity(d);
			bpj.setZip(e);
			bpj.setUsernm(f);
			bpj.setMob(g);
			bpj.setEmail(h);
			bpj.setAdhr(i);
			bpj.setPan(j);
			bpj.setPolicy(k);
			System.out.println("Working");
			Transaction tx=ss.beginTransaction();
			ss.save(bpj);
			tx.commit();
			ss.close();
			res.sendRedirect("success.html");
		}
		catch(Exception ae)
		{	ae.printStackTrace();	}	}
}
