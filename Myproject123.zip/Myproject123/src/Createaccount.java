
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


@WebServlet("/Createaccount")
public class Createaccount extends HttpServlet {
	
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
				try
			{	res.setContentType("text/html");
				PrintWriter pw=res.getWriter();
				String a=req.getParameter("t1");
				String b=req.getParameter("t2");
				String c=req.getParameter("t3");
				String d=req.getParameter("t4");
				String e=req.getParameter("t5");
				int f=Integer.parseInt(e);
				String g=req.getParameter("t6");
				String h=req.getParameter("t7");
				String i=req.getParameter("t8");
				int j=Integer.parseInt(i);
				String k=req.getParameter("t9");
				int l=Integer.parseInt(k);
				String m=req.getParameter("t10");
				String n=req.getParameter("t11");
				Configuration cfg=new Configuration();
				SessionFactory sf=cfg.configure().buildSessionFactory();
				Session ss=sf.openSession();
				mypojo1 pojo=new mypojo1();
				pojo.setFirstname(a);
				pojo.setLastname(b);
				pojo.setUsername(c);
				pojo.setEmail(d);
				pojo.setPhone(f);
				pojo.setAddress(g);
				pojo.setCity(h);
				pojo.setZip(j);
				pojo.setAadhar(l);
				pojo.setPan(m);
				pojo.setPolicy(n);
				Transaction tx=ss.beginTransaction();
				ss.save(pojo);
				tx.commit();
				ss.close();
				System.out.println("hi");
				//res.sendRedirect("success.html");
			}
			catch(Exception ae)
			{	ae.printStackTrace();	}
	
	
	
	}

}
